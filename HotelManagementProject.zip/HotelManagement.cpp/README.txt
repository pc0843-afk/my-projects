Project: Hotel Management System

Language: C++

Description:
A simple console-based hotel management system.

Features:
- Book room
- Display records
- Search customer

Concepts Used:
- Classes
- Arrays
- Loops

Note:
Program was compiled and tested using an online compiler.