Student Management System (Java)

Features:
- Add student
- Display student
- Search student

Concepts used:
- OOP
- ArrayList
- Scanner

Run:
javac StudentManagement.java
java StudentManagement