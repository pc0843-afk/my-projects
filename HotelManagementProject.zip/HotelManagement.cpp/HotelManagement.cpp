#include <iostream>
using namespace std;

class Hotel {
public:
    int roomNo;
    string name;

    void input() {
        cout << "Enter Room No: ";
        cin >> roomNo;
        cout << "Enter Customer Name: ";
        cin >> name;
    }

    void display() {
        cout << "Room No: " << roomNo << ", Name: " << name << endl;
    }
};

int main() {
    Hotel h[100];
    int count = 0;
    int choice;

    do {
        cout << "\n===== Hotel Management System =====\n";
        cout << "1. Book Room\n";
        cout << "2. Display All\n";
        cout << "3. Search Customer\n";
        cout << "4. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch(choice) {

            case 1:
                h[count].input();
                count++;
                cout << "Room booked successfully!\n";
                break;

            case 2:
                if (count == 0) {
                    cout << "No records found!\n";
                } else {
                    for (int i = 0; i < count; i++) {
                        h[i].display();
                    }
                }
                break;

            case 3: {
                int room;
                cout << "Enter Room No to search: ";
                cin >> room;
                bool found = false;

                for (int i = 0; i < count; i++) {
                    if (h[i].roomNo == room) {
                        h[i].display();
                        found = true;
                    }
                }

                if (!found) {
                    cout << "Customer not found!\n";
                }
                break;
            }

            case 4:
                cout << "Exiting...\n";
                break;

            default:
                cout << "Invalid choice!\n";
        }

    } while (choice != 4);

    return 0;
}